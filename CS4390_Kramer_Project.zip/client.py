import socket

def run_client(command):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_addr = ('10.0.0.2', 12345)

    client_socket.connect(server_addr)

    client_socket.send(command.encode())

    response = client_socket.recv(1024).decode()
    print(f"Response: {response}")

    client_socket.close()

if __name__ == "__main__":
    while True:
        user_input = input("Enter command (e.g., 'GET FR', 'SET FR ON', 'SET T 80', 'GET ALL', 'EXIT'): ")
        if user_input == 'EXIT':
            break
        run_client(user_input)
