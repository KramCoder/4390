import socket

# Define the initial status of smart devices
smart_devices = {
    'FR': 'OFF',  # Family Room light switch
    'K': 'OFF',   # Kitchen light switch
    'T': 75.0     # Thermostat temperature setting
}

def get_device_status(device_name):
    if device_name == 'ALL':
        return smart_devices
    return smart_devices.get(device_name, 'Device not found')

def set_device_status(device_name, status):
    if device_name == 'T' and isinstance(status, (int, float)):
        smart_devices['T'] = float(status)
    elif device_name in ['FR', 'K'] and status in ['ON', 'OFF']:
        smart_devices[device_name] = status
    else:
        return "Invalid command"

def run_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 12345))
    server_socket.listen(1)
    print("Server is listening on port 12345...")

    while True:
        conn, addr = server_socket.accept()
        print(f"Connection from {addr[0]}:{addr[1]}")

        data = conn.recv(1024).decode()
        command = data.strip().split(' ')
        
        if len(command) == 1:
            response = get_device_status(command[0])
        elif len(command) == 2:
            response = set_device_status(command[0], command[1])
        else:
            response = "Invalid command"

        conn.send(str(response).encode())

        conn.close()

if __name__ == "__main__":
    run_server()
