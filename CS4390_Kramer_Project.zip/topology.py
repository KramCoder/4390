from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import CPULimitedHost
from mininet.link import TCLink
from mininet.util import irange

class CustomTopology(Topo):
    def build(self):
        switch = self.addSwitch('s1')
        host1 = self.addHost('h1', cpu=0.5)  # Client
        host2 = self.addHost('h2', cpu=0.5)  # Server

        # Add links between the hosts and the switch
        self.addLink(host1, switch, bw=10, delay='5ms', loss=0, max_queue_size=1000, use_htb=True)
        self.addLink(host2, switch, bw=10, delay='5ms', loss=0, max_queue_size=1000, use_htb=True)

def run_mininet():
    topo = CustomTopology()
    net = Mininet(topo=topo, host=CPULimitedHost, link=TCLink)
    net.start()

    # Set IP addresses for the hosts
    h1, h2 = net.get('h1', 'h2')
    h1.cmd('ifconfig h1-eth0 10.0.0.1/24')
    h2.cmd('ifconfig h2-eth0 10.0.0.2/24')

    return net

if __name__ == '__main__':
    mininet_instance = run_mininet()
    mininet_instance.interact()
